# MAC Discoteque — exportación para Cloudflare Pages

Proyecto original recuperado de MAC Discotec Producciones, versión Sites 11.
Origen: https://mac-discotec-producciones.ventasvalientesergio.chatgpt.site
Commit de origen: b99a9c405057dd1c71565e3ed2dd1e4b2ef385a4

## Contenido
- dist/: fuente original y versión lista para publicar. Es HTML estático: no existe una compilación separada. index.html contiene HTML, CSS, animaciones y JavaScript editables.
- MAC-Discoteque-publicar.zip: los mismos archivos en la raíz del ZIP para publicación manual.
- SHA256SUMS.txt: hashes de los archivos originales.

## GitHub y Cloudflare Pages
1. Extraer este paquete. Subir README.md, SHA256SUMS.txt y dist/ al repositorio GitHub. El ZIP interior es solo para publicación manual y no necesita subirse a GitHub.
2. En Cloudflare, crear un proyecto Pages y conectar ese repositorio.
3. Preset: None. Rama de producción: main (o la rama utilizada).
4. Comando de compilación: exit 0. Carpeta de salida: dist. Raíz del proyecto: raíz del repositorio.
5. Variables de entorno: ninguna. No requiere npm, Node, paquetes, instalación ni backend.
6. Publicar. Para cambios posteriores, editar dist/index.html o sus imágenes y enviar los cambios a GitHub.

Documentación oficial:
https://developers.cloudflare.com/pages/framework-guides/deploy-anything/
https://developers.cloudflare.com/pages/get-started/git-integration/

## Publicación manual
Usar MAC-Discoteque-publicar.zip, cuyos archivos están directamente en la raíz, o subir la carpeta dist. No subir este paquete completo como si fuera la web.
Para continuar desde GitHub, conviene crear desde el inicio el proyecto Pages con integración Git.

## Funcionalidad y configuración adicional
- Navegación por anclas, tarjetas generadas con JavaScript, desplegables y animaciones: funcionan en el navegador, sin backend.
- Formulario: prepara un mensaje y trata de copiarlo al portapapeles; no envía ni almacena consultas. El sitio ya mostraba que faltaba el número comercial de WhatsApp. El comportamiento y los textos se conservaron.
- Portapapeles: requiere HTTPS y permiso del navegador. El código original muestra éxito incluso si falla la copia; no se corrigió para respetar el alcance.
- Menú móvil: el botón original no tiene un controlador JavaScript asociado. Se conserva, no es una regresión de migración.
- Google Fonts: Archivo Black y Manrope se cargan desde fonts.googleapis.com/fonts.gstatic.com, igual que en el original. Requieren internet; si se bloquean se utilizan las fuentes alternativas actuales. No hay dependencias npm.
- Selfie Fiesta Live: es un enlace externo al sitio existente; no contiene ni exporta ese otro proyecto.
- No hay APIs, base de datos, sesiones, Workers, Functions ni variables de entorno en este código.
- Activar envío real por WhatsApp o guardar solicitudes sería un cambio posterior, fuera de esta exportación.

## Conservación y verificación
Todos los archivos de dist son idénticos byte a byte al checkout original: Hero, contenido, precios, navegación, estilos, imágenes y scripts sin cambios.
Se comprobó la presencia de todas las imágenes referenciadas y la sintaxis de ambos scripts con node --check.
No se realizó prueba visual en navegador ni publicación en Cloudflare; esa validación queda pendiente después del despliegue.
Se incluye también mac-discotec-vinyl.jpg porque forma parte de los recursos originales, aunque actualmente no está referenciado.
Se excluyeron historial Git, metadatos privados de hosting, credenciales y archivos temporales.
